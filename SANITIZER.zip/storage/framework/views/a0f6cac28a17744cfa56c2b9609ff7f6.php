<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Our Website</title>
</head>
<body>
    <h1>SMART DUSTBIN</h1>
    <p>Dear Collector,</p>
    <p>I hope this message finds you well. This Email request an urgent waste collection for the bin located at <?php echo e($data['address']); ?>. The bin is currently full, and we kindly request your immediate attention to empty it.</p>
    <p>Bin Location: <?php echo e($data['address']); ?></p>
    <p>Bin Type/Size: <?php echo e($data['category']); ?></p>
    <p>Date and Time of Notice: <?php echo e($data['time']); ?></p>
    <p>Best regards,</p>
    <p>Your System Team</p>
</body>
</html>
<?php /**PATH /home/audace/Desktop/PERSON/part-time/dast_bin/resources/views/email.blade.php ENDPATH**/ ?>