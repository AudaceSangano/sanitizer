<?php $__env->startSection('contents'); ?>

<!-- Content Row -->

<div class="row">

    <div class="col-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div
                class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Dustbin Registration Form</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                
                    <?php $__errorArgs = ['user_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger text-primary font-18 text-center"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <form action="<?php echo e(route('dust.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row mt-2">
                            <div class="col-6">
                                <input type="text" class="form-control" name="location" value="<?php echo e($data->address); ?>" required>
                                <input type="hidden" class="form-control" name="id" value="<?php echo e($data->st_id); ?>" required>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" value="<?php echo e($data->st_id); ?> This is your Dustbin Id" readonly required>
                            </div>
                            <div class="col-6 mt-3">
                                <select class="form-control" name="collector" required>
                                    <?php
                                        $users = DB::table('users')->where('role_id', 2)->get();
                                    ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e($user->id==$data->st_collector?'selected':''); ?>><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-warning">
                            Save change
                        </button>
                    </form>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/audace/Desktop/PERSON/part-time/sanitizer/resources/views/layout/dustupdate.blade.php ENDPATH**/ ?>