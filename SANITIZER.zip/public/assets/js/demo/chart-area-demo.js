// Set new default font family and font color to mimic Bootstrap's default styling

